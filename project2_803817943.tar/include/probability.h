/*
 * probability.h
 *
 *  Created on: Nov 25, 2013
 *      Author: spencer
 */

#ifndef PROBABILITY_H_
#define PROBABILITY_H_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <time.h>

bool p_check(double probability);
void seed();


#endif /* PROBABILITY_H_ */
